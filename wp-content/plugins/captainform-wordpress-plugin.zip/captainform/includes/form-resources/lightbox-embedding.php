<script type="text/javascript">
	var customVarsMF = '{{CUSTOMVARS}}';
	var captainform_theme_style = '{{STYLE}}';
</script>
<a href="javascript:" {{BUTTON_STYLE}} class="blueLink13"
   onclick="captainform_create_form_popup({url: cfJsHost + captainform_servicedomain + '/form-{{ID}}/?' + customVarsMF + captainform_theme_style, popup_w: 1000})">{{CONTENT}}</a>